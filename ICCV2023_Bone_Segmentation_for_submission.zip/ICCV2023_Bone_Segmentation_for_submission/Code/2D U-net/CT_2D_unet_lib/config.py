

#FocalTverskyLoss parameter
ALPHA = 0.5
BETA = 0.5
GAMMA = 1

#Train
LR = 1e-3
BATCH = 1
EPOCH = 100