[How to Run]
	1. Open "~/download_datasets_and_model.ipynb" and run all.
	2. Open "~/Code/2D U-net/Segmentation_v1_15_reverse/main.ipynb" and run all.
	3. Open "~/Code/3D U-net/Segmentation_v1_15_reverse/main.ipynb" and run all.
	4. Open "~/Code/3D O-net/Segmentation_v1_15_reverse/main.ipynb" and run all.